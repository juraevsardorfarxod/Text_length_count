// Select HTML elements
let elUserForm=document.querySelector('.user_form');
let elUserInput=document.querySelector('.user_input');
let elResult=document.querySelector('.result');

// function of word length

function wordCount() {
   let arrayCutDescription=elUserInput.value.split(' ');
   let wordLength=0;
   let maxWord='';
   for(let word of arrayCutDescription) {
      if(wordLength<word.length) {
         maxWord=word;
         wordLength=word.length;
      }
   }
   return maxWord;
}

// write on HTML

function handleDescription(evt) {
   evt.preventDefault();
   elResult.textContent=wordCount();
}

// submit 

elUserForm.addEventListener('submit', handleDescription)

